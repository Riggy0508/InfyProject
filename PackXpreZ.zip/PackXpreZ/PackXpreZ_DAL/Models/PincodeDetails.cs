﻿using System;
using System.Collections.Generic;

namespace Infosys.PackXpreZ.DataAccessLayer.Models
{
    public partial class PincodeDetails
    {
        public decimal Pincode { get; set; }
        public string Location { get; set; }
    }
}
