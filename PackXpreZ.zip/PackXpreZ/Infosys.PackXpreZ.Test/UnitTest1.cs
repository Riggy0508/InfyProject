using Microsoft.VisualStudio.TestTools.UnitTesting;
using Infosys.PackXpreZ.DataAccessLayer;

namespace Infosys.PackXpreZ.Test
{
    [TestClass]
    public class UnitTest1
    {
        CustomerRepository rep = new CustomerRepository();

        [TestMethod]
        public void Test1_Positive()
        {
        }
        [TestMethod]
        public void Test2_Positive()
        {

        }
        [TestMethod]
        public void Test3_Positive()
        {

        }
        [TestMethod]
        public void Test4_Positive()
        {

        }
        [TestMethod]
        public void Test5_Positive()
        {

        }
        [TestMethod]
        public void Test1_Positive()
        {

        }
    }
}
