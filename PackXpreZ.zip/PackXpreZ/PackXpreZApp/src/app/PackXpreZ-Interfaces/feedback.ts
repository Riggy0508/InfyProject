export interface IFeedback {
  feedbackId: number;
  emailId: string;
  feedBackType: string;
  feedBackText: string;
  actionTaken: string;
}
