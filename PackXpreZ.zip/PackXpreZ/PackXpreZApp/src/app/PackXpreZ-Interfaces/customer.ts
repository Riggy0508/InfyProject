export interface ICustomerDetails {
        EmailId: string;
  customerName: string;
        Password: string;
  contactNo: string;

}
