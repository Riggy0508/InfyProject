export interface IBranchOfficer {
  OfficerEmail: string;
  OfficerName: string;
  Password: string;
  BranchName: string;
  Pincode: number;
}
