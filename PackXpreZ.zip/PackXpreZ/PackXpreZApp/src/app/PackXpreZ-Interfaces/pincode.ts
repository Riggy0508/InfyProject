export interface IPincode {
        Pincode: number;
        Location: string;

}
