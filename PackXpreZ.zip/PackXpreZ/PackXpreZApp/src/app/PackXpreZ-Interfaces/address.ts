export interface IAddress {
        AddressId: number;
        EmailId: string;
  buildingNo: string;
  streetName: string;
  locality: string;
  city: string;
  state: string;
  pincode: number;
}
