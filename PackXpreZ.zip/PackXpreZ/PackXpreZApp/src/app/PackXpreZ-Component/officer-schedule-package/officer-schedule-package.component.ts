import { Component, OnInit } from '@angular/core';
import { PackXprezService } from '../../PackXpreZ-Services/pack-xprez.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-officer-schedule-package',
  templateUrl: './officer-schedule-package.component.html',
  styleUrls: ['./officer-schedule-package.component.css']
})
export class OfficerSchedulePackageComponent implements OnInit {

  emailID: string;
  cost: number;
  distance: number;
  volume: number;
  insurance: boolean;
  time: number;

  constructor(private _service: PackXprezService, private _route: ActivatedRoute, private _router: Router) {
    this.distance = this._route.snapshot.params['distance'];
    this.volume = 0;
  }

  ngOnInit() {
  }

  offSchedulePackage(form: NgForm) {
    console.log("TheForm Value:", form.value);

    this.emailID = form.value.mail;

    if (parseInt(form.value.estCost) >= 1000)
      this.insurance = true;
    else
      this.insurance = false;

    this.time = parseInt(form.value.timeslot)

    this.volume = form.value.length * form.value.breadth * form.value.width;

    this.cost = this.distance * 7;
    this.cost = this.cost + this.volume * 0.5;
    this.cost = this.cost + form.value.weight * 0.75;

    if (form.value.mode == "OVERNIGHT") {
      this.cost = this.cost + 500;
    }
    else if (form.value.mode == "EXPRESS") {
      this.cost = this.cost + 100;
    }

    if (form.value.packaging) {
      this.cost + this.cost + 100;
    }

    this._service.oSchedulePackage(this.emailID, form.value.senaddr, form.value.recaddr, this.time, this.insurance, this.cost, form.value.mode, form.value.packaging).subscribe(

      succ => {
        console.log(succ);
        alert("Package Scheduled Successfully..!");
        this._router.navigate(['/officerhistory']);
      },
      err => {
        console.log(err);
        alert("Package Scheduling Failed, Try Again..!");
      },
      () => { console.log("Officer Schedule Package Method"); }
    );
  }

  goBack() {
    this._router.navigate(['/officerhistory']);
  }

}
